<?php
require 'db.php';
$playerID = 1;
$itemID = $_POST['item_id'];

try {
    $pdo->beginTransaction();

    // FIXED: We are now selecting BOTH Credits and Location from the player!
    $stmt = $pdo->prepare("SELECT Credits, Location FROM players WHERE PlayerID = ? FOR UPDATE");
    $stmt->execute([$playerID]);
    $player = $stmt->fetch();

    // ... inside the try block, right after fetching $player ...

    // NEW: Check Cargo Capacity (Max 5 items)
    $stmt = $pdo->prepare("SELECT COUNT(*) as TotalItems FROM inventory WHERE PlayerID = ?");
    $stmt->execute([$playerID]);
    $invCount = $stmt->fetch();

    if ($invCount['TotalItems'] >= 5) {
        echo json_encode(["status" => "error", "msg" => "CARGO HOLD FULL. Maximum 5 items."]);
        exit;
    }

    // Fetch dynamic item price based on CURRENT LOCATION
    $stmt = $pdo->prepare("SELECT Price FROM market_prices WHERE ItemID = ? AND Location = ?");
    $stmt->execute([$itemID, $player['Location']]);
    $item = $stmt->fetch();

    

    // Validate player has enough credits
    if ($player['Credits'] >= $item['Price']) {
        
        // 1. Deduct Credits
        $stmt = $pdo->prepare("UPDATE players SET Credits = Credits - ? WHERE PlayerID = ?");
        $stmt->execute([$item['Price'], $playerID]);

        // 2. Add to inventory
        $stmt = $pdo->prepare("INSERT INTO inventory (PlayerID, ItemID) VALUES (?, ?)");
        $stmt->execute([$playerID, $itemID]);

        // 3. Log Transaction
        $stmt = $pdo->prepare("INSERT INTO transactions (PlayerID, ItemID, AmountSpent, ActionType) VALUES (?, ?, ?, 'BUY')");
        $stmt->execute([$playerID, $itemID, $item['Price']]);

        $pdo->commit();
        echo json_encode(["status" => "success", "msg" => "Cargo purchased!"]);
    } else {
        $pdo->rollBack();
        echo json_encode(["status" => "error", "msg" => "Not enough credits."]);
    }
} catch (Exception $e) {
    $pdo->rollBack();
    // Appended the error message here so if it fails again, you can see EXACTLY why!
    echo json_encode(["status" => "error", "msg" => "Transaction failed: " . $e->getMessage()]);
}
?>