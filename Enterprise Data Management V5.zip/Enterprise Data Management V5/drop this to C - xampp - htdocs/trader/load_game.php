<?php
require 'db.php';
$playerID = 1;

// Fetch Player
$stmt = $pdo->prepare("SELECT * FROM players WHERE PlayerID = ?");
$stmt->execute([$playerID]);
$player = $stmt->fetch();
$loc = $player['Location'];

// Fetch Local Market (JOIN items and market_prices)
$stmt = $pdo->prepare("SELECT i.ItemID, i.ItemName, m.Price FROM items i JOIN market_prices m ON i.ItemID = m.ItemID WHERE m.Location = ?");
$stmt->execute([$loc]);
$market = $stmt->fetchAll();

// Fetch Inventory with Local Sell Prices
$stmt = $pdo->prepare("SELECT i.ItemID, i.ItemName, COUNT(inv.ItemID) as Qty, m.Price as SellPrice FROM inventory inv JOIN items i ON inv.ItemID = i.ItemID JOIN market_prices m ON i.ItemID = m.ItemID WHERE inv.PlayerID = ? AND m.Location = ? GROUP BY i.ItemID");
$stmt->execute([$playerID, $loc]);
$inventory = $stmt->fetchAll();

// Fetch Ship's Log (Last 5 Transactions)
$stmt = $pdo->prepare("SELECT i.ItemName, t.AmountSpent, t.ActionType, t.LogDate FROM transactions t JOIN items i ON t.ItemID = i.ItemID WHERE t.PlayerID = ? ORDER BY t.LogDate DESC LIMIT 5");
$stmt->execute([$playerID]);
$logs = $stmt->fetchAll();

// Fetch Planet Healths
$stmt = $pdo->query("SELECT Name, Health FROM planets");
$planets = $stmt->fetchAll();

echo json_encode([
    "player" => $player, 
    "market" => $market, 
    "inventory" => $inventory, 
    "logs" => $logs, 
    "planets" => $planets
    ]);
?>