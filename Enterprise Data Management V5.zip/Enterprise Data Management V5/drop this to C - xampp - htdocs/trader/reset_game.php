<?php
require 'db.php';
$pdo->exec("DELETE FROM inventory; DELETE FROM transactions;");
$pdo->exec("UPDATE players SET Credits = 0, Location = 'Earth' WHERE PlayerID = 1;");
$pdo->exec("UPDATE planets SET Health = 100;");
echo json_encode(["status" => "success"]);
?>