<?php
require 'db.php';
$playerID = 1;

$credits = isset($_POST['credits']) ? (int)$_POST['credits'] : 0;
$localDamage = isset($_POST['damage']) ? (int)$_POST['damage'] : 0;
$globalDecay = isset($_POST['decay']) ? (int)$_POST['decay'] : 0; // NEW: Idle Drain

if ($credits > 0 || $localDamage > 0 || $globalDecay > 0) {
    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("SELECT Location FROM players WHERE PlayerID = ? FOR UPDATE");
        $stmt->execute([$playerID]);
        $player = $stmt->fetch();

        // 1. Apply Credits
        if ($credits > 0) {
            $stmt = $pdo->prepare("UPDATE players SET Credits = Credits + ? WHERE PlayerID = ?");
            $stmt->execute([$credits, $playerID]);
        }

        // 2. Apply Laser Mining Damage to LOCAL planet
        if ($localDamage > 0) {
            $stmt = $pdo->prepare("UPDATE planets SET Health = Health - ? WHERE Name = ?");
            $stmt->execute([$localDamage, $player['Location']]);
        }

        // 3. Apply Passive Idle Decay to ALL planets
        if ($globalDecay > 0) {
            $stmt = $pdo->prepare("UPDATE planets SET Health = Health - ?");
            $stmt->execute([$globalDecay]);
        }

        $pdo->commit();
        echo json_encode(["status" => "success"]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(["status" => "error"]);
    }
}
?>