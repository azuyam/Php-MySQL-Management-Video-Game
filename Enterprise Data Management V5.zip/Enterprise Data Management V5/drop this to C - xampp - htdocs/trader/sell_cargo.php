<?php
require 'db.php';
$playerID = 1;
$itemID = $_POST['item_id'];

try {
    $pdo->beginTransaction();

    // 1. Lock player and get current location
    $stmt = $pdo->prepare("SELECT Credits, Location FROM players WHERE PlayerID = ? FOR UPDATE");
    $stmt->execute([$playerID]);
    $player = $stmt->fetch();

    // 2. Check if player actually owns at least one of this item
    $stmt = $pdo->prepare("SELECT InventoryID FROM inventory WHERE PlayerID = ? AND ItemID = ? LIMIT 1");
    $stmt->execute([$playerID, $itemID]);
    $ownedItem = $stmt->fetch();

    if ($ownedItem) {
        // 3. Get the sell price at the CURRENT location
        $stmt = $pdo->prepare("SELECT Price FROM market_prices WHERE ItemID = ? AND Location = ?");
        $stmt->execute([$itemID, $player['Location']]);
        $market = $stmt->fetch();

        // 4. Delete EXACTLY ONE crate from inventory
        $stmt = $pdo->prepare("DELETE FROM inventory WHERE InventoryID = ?");
        $stmt->execute([$ownedItem['InventoryID']]);

        // 5. Add Credits to Player
        $stmt = $pdo->prepare("UPDATE players SET Credits = Credits + ? WHERE PlayerID = ?");
        $stmt->execute([$market['Price'], $playerID]);

        // 6. Log the Transaction as a 'SELL'
        $stmt = $pdo->prepare("INSERT INTO transactions (PlayerID, ItemID, AmountSpent, ActionType) VALUES (?, ?, ?, 'SELL')");
        $stmt->execute([$playerID, $itemID, $market['Price']]);

        // NEW: Restore 15 Health to the current planet
        $stmt = $pdo->prepare("UPDATE planets SET Health = Health + 15 WHERE Name = ?");
        $stmt->execute([$player['Location']]);

        $pdo->commit();
        echo json_encode(["status" => "success", "msg" => "+{$market['Price']} CR (Sold)"]);
    } else {
        $pdo->rollBack();
        echo json_encode(["status" => "error", "msg" => "Item not in inventory."]);
    }
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(["status" => "error", "msg" => "Transaction failed."]);
}
?>