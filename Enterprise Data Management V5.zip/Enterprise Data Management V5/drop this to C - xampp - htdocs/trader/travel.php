<?php
require 'db.php';
$playerID = 1;
$destination = $_POST['destination'];

try {
    $pdo->beginTransaction();

    // 1. Lock the player and check current location
    $stmt = $pdo->prepare("SELECT Location FROM players WHERE PlayerID = ? FOR UPDATE");
    $stmt->execute([$playerID]);
    $player = $stmt->fetch();

    // BUG FIX: Prevent traveling to the same planet
    if ($player['Location'] === $destination) {
        $pdo->rollBack();
        echo json_encode(["status" => "error", "msg" => "Already in orbit."]);
        exit;
    }

    // 2. Move Player
    $stmt = $pdo->prepare("UPDATE players SET Location = ? WHERE PlayerID = ?");
    $stmt->execute([$destination, $playerID]);

    // 3. Drain Resources (Both planets suffer while you travel)
    $stmt = $pdo->prepare("UPDATE planets SET Health = Health - 15");
    $stmt->execute();

    $pdo->commit();
    echo json_encode(["status" => "success"]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(["status" => "error"]);
}
?>